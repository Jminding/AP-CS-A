package TicTacToeWithAI;

public class Mark {
    public final char mark; // The actual mark, a char that is either 'X' or 'O'

    public Mark(char x) {
        mark = x;
    }
}
